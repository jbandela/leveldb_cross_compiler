Packaged library for leveldb_cc

The files are from
https://github.com/jbandela/leveldb_cross_compiler

and 

https://github.com/jbandela/cross_compiler_call

This is an adaptation of leveldb.  The leveldb source comes from

https://github.com/bitcoin/bitcoin/tree/master/src/leveldb 

msys and ming g++ 4.7.2 from nuwen.net were use to build

leveldb_cc_dll.dll

Files by me are released under the Boost Software License
